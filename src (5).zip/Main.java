import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        final String text;
        final int THREAD_COUNT;
        try {
            StringBuilder builder = new StringBuilder();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
            THREAD_COUNT = Integer.parseInt(bufferedReader.readLine());
            String line;
            while (true) {
                line = bufferedReader.readLine();
                if (line.equals("!end"))
                    break;
                builder.append(line).append("\n");
            }
            text = builder.substring(0, builder.length() - 1);
            bufferedReader.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        List<String> saparatedWords = saparateWords(text);
        int wordsPerThread = saparatedWords.size() / THREAD_COUNT;
        List<List<String>> wordsForEachThread = makingSubLists(wordsPerThread,
                saparatedWords);
        Map<String, Integer> results = workingWithThread(wordsForEachThread, text, THREAD_COUNT);
        int finalWordCount = calculateFinalTotalwords(results);
        String longestWord = getLongestWord(saparatedWords);
        String mostFrequentWord = calculateMostFrequentedWord(results);
        double hackCode = Threads.getHackCode();
        printResults(finalWordCount, longestWord, mostFrequentWord, results, hackCode);
    }

    private static void printResults(int finalWordCount, String longestWord,
                                     String mostFrequentWord, Map<String, Integer> finalResults,
                                     double hackCode) {
        System.out.printf("Word count: %d\n", finalWordCount);
        System.out.printf("The longest word is \"%s\" with a length of %d.\n", longestWord, longestWord.length());
        System.out.printf("The most frequent word is \"%s\" with %d appearances.\n", mostFrequentWord, finalResults.get(mostFrequentWord));
        System.out.printf("HackCode: %.3f\n", hackCode);
    }

    private static String calculateMostFrequentedWord(Map<String, Integer> finalResults) {
        String mostFrequentWord = "";
        int maxFrequency = 0;
        for (Map.Entry<String, Integer> entry : finalResults.entrySet()) {
            if (entry.getValue() > maxFrequency) {
                mostFrequentWord = entry.getKey();
                maxFrequency = entry.getValue();
            }
        }
        return mostFrequentWord;
    }

    private static String getLongestWord(List<String> saparatedWords) {
        String longestWord = "";
        for (String word : saparatedWords) {
            if (word.length() > longestWord.length()) {
                longestWord = word;
            }
        }
        return longestWord;
    }

    private static int calculateFinalTotalwords(Map<String, Integer> finalResults) {
        int finalWordCount = 0;
        for (int count : finalResults.values()) {
            finalWordCount += count;
        }
        return finalWordCount;
    }

    private static List<String> saparateWords(String text) {
        List<String> separated = new ArrayList<>();
        StringBuilder word = new StringBuilder();
        for (char c : text.toCharArray()) {
            if (Character.isAlphabetic(c)) {
                word.append(c);
            } else if (word.length() > 0) {
                separated.add(word.toString());
                word = new StringBuilder();
            }
        }
        // Add the last word if there is one
        if (word.length() > 0)
            separated.add(word.toString());
        return separated;
    }

    private static List<List<String>> makingSubLists(int wordsPerThread, List<String> separatedWords) {
        List<List<String>> subLists = new ArrayList<>();
        for (int i = 0; i < separatedWords.size(); i += wordsPerThread) {
            int end = Math.min(i + wordsPerThread, separatedWords.size());
            subLists.add(separatedWords.subList(i, end));
        }
        return subLists;
    }

    private static Map<String, Integer> workingWithThread(List<List<String>> wordsForEachThread,
                                                          String text, int THREAD_COUNT) {
        Map<String, Integer> results = new HashMap<>();
        ArrayList<Threads> threads = new ArrayList<>();
        int chunkSize = text.length() / THREAD_COUNT;
        int startIndex = 0;
        int endIndex = chunkSize;
        for (int i = 0; i < wordsForEachThread.size(); i++) {
            if (i == THREAD_COUNT - 1) {
                // Last thread takes the remaining portion of the text
                endIndex = text.length();
            }
            String segment = text.substring(startIndex, endIndex);
            Threads thread = new Threads(wordsForEachThread.get(i), results, text, startIndex, endIndex);
            thread.start();
            threads.add(thread);
            startIndex = endIndex;
            endIndex = Math.min(endIndex + chunkSize, text.length());
        }
        for (Threads thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
        return results;
    }
}