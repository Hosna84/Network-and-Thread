import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;


public class Threads extends Thread {
    private List<String> saparatedWords;
    private Map<String, Integer> result;
    private static double totalHackCode = 0;
    private static final Object lock = new Object();
    private String text;
    private int start;
    private int end;

    public Threads(List<String> saparatedWords, Map<String, Integer> result, String text, int start, int end) {
        this.saparatedWords = saparatedWords;
        this.result = result;
        this.text = text;
        this.start = start;
        this.end = end;
    }

    private void calculateHackCode() {
        double zarib = 0.99998;
        double hackCode = 0;
        for (int i = this.end - 1; i >= this.start; i--) {
            hackCode += this.text.codePointAt(i) * Math.pow(zarib,
                    this.text.length() - i - 1);
        }
        synchronized (lock) {
            totalHackCode += hackCode;
        }
    }

    public static double getHackCode() {
        return totalHackCode;
    }

    @Override
    public void run() {
        for (int i = 0; i < saparatedWords.size(); i++) {
            synchronized (result) {
                if (result.containsKey(saparatedWords.get(i).toLowerCase())) {
                    result.replace(saparatedWords.get(i).toLowerCase(),
                            result.get(saparatedWords.get(i).toLowerCase()) + 1);
                } else result.put(saparatedWords.get(i).toLowerCase(), 1);
            }
        }
        calculateHackCode();
    }
}
