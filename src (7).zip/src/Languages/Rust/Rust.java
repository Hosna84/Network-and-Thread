package Languages.Rust;

import Languages.Code;
import Languages.Java.Java;
import Transpiler.AbstractSyntaxTree;
import Transpiler.RuleType;

import java.io.StringReader;

public class Rust extends Code {

    public Rust(String code) {
        super(code);
    }

    public Rust(AbstractSyntaxTree ast) {
        super(ast);
    }

    @Override
    public AbstractSyntaxTree parseToAST() {
        /**
         * This function parses the given program code with Rust Parser.
         * @return Parsed AST (Abstract Syntax Tree) of the given Program.
         */
        RustLexer lexer = new RustLexer(new StringReader(this.code));
        RustParser parser = new RustParser(lexer);
        try {
            Object result = parser.parse().value;
            this.ast = (AbstractSyntaxTree) result;
            return this.ast;
        } catch (Exception e) {
            System.err.println("Parser error: " + e.getMessage());
            this.ast = null;
            return null;
        }
    }

    @Override
    public String generateCode() {
        AbstractSyntaxTree tree = this.ast;
        StringBuilder generatedCode = new StringBuilder();
        if (tree == null)
            return generatedCode.toString();
        switch (tree.getType()) {
            case IF:
                ifStatement(tree, generatedCode);
                break;
            case PROGRAM:
                programStatement(tree, generatedCode);
                break;
            case STATEMENTS:
                statementsStatement(tree, generatedCode);
                break;
            case STATEMENT:
                statementstatement(tree, generatedCode);
                break;
            case DECLARATION:
                generatedCode.append("let ");
                generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
                break;
            case ASSIGNMENT:
                assignmentStmnt(tree, generatedCode);
                break;
            case FOLLOW_STATEMENTS:
                followStatemnet(tree, generatedCode);
                break;
            case SWITCH:
                swichStatement(tree, generatedCode);
                break;
            case CASES:
                generateCases(tree, generatedCode);
                break;
            case WHILE:
                whileStatement(tree, generatedCode);
                break;
            case DISJUNCTION:
                disjunctionStatment(tree, generatedCode);
                break;
            case CONJUNCTION:
                conjunctionStatement(tree, generatedCode);
                break;
            case INVERSION:
                inversionStatement(tree, generatedCode);
                break;
            case COMPARISON:
                comparisonStatement(tree, generatedCode);
                break;
            case EQ:
                equalityStatement(tree, generatedCode);
                break;
            case LT:
                ltStatement(tree, generatedCode);
                break;
            case GT:
                gtStatement(tree, generatedCode);
                break;
            case SUM:
                sumStatement(tree, generatedCode);
                break;
            case TERM:
                termStatement(tree, generatedCode);
                break;
            case MODULO:
                modulaStatement(tree, generatedCode);
                break;
            case FACTOR:
                factorStatement(tree, generatedCode);
                break;
            case PRIMARY:
                primaryStatement(tree, generatedCode);
                break;
            case NUM, ID:
                generatedCode.append(tree.getLexeme());
                break;
            case ASSIGNMENTS:
                assignments(tree, generatedCode);
                break;
            case PRINT:
                generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
                break;
            case OPTIONS:
                options(tree, generatedCode);
                break;
        }
        return generatedCode.toString();
    }

    private static void options(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        if (tree.getSubType().equals(RuleType.MULTI)) {
            generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
            generatedCode.append(" | ");
            generatedCode.append(new Rust(tree.getChildren().get(1)).generateCode());
        } else {
            generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
        }
    }

    private static void assignments(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        if (tree.getSubType().equals(RuleType.MULTI) && tree.getChildren().size() >= 2) {
            generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
            generatedCode.append(";\n");
            generatedCode.append("let ");
            generatedCode.append(new Rust(tree.getChildren().get(1)).generateCode());
        } else
            generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
    }

    private void primaryStatement(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
    }

    private void factorStatement(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        if (tree.getSubType().equals(RuleType.POSITIVE)) {
            generatedCode.append("+");
            generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
            return;
        }
        if (tree.getSubType().equals(RuleType.NEGATIVE)) {
            generatedCode.append("-");
            generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
            return;
        }
        if (tree.getSubType().equals(RuleType.PAR)) {
            generatedCode.append("(");
            generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
            generatedCode.append(")");
            return;
        }
        if (tree.getSubType().equals(RuleType.DEFAULT))
            generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
        return;

    }

    private void statementstatement(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        switch (tree.getSubType()) {
            case DECLARE, ASSIGNMENTS:
                generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
                generatedCode.append(";\n");
                break;
            case BREAK:
                generatedCode.append("break;\n");
                break;
            case CONTINUE:
                generatedCode.append("continue;\n");
                break;
            case PRINT:
                generatedCode.append("println!(");
                generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
                generatedCode.append(");\n");
                break;
            case IF:
                generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
                break;
            case WHILE:
                generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
                break;
            case SWITCH:
                generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
                break;
        }
    }

    private static void modulaStatement(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        switch (tree.getSubType()) {
            case MULTI -> {
                generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
                generatedCode.append(" % ");
                generatedCode.append(new Rust(tree.getChildren().get(1)).generateCode());
            }
            default -> {
                generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
            }
        }
    }

    private static void termStatement(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        if (tree.getSubType().equals(RuleType.TIMES)) {
            generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
            generatedCode.append(" * ");
            generatedCode.append(new Rust(tree.getChildren().get(1)).generateCode());
            return;
        }
        if (tree.getSubType().equals(RuleType.DIVIDES)) {
            generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
            generatedCode.append(" / ");
            generatedCode.append(new Rust(tree.getChildren().get(1)).generateCode());
            return;
        }
        if (tree.getSubType().equals(RuleType.DEFAULT)) {
            generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
            return;
        }
    }

    private static void sumStatement(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        if (tree.getSubType().equals(RuleType.ADD)) {
            generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
            generatedCode.append(" + ");
            generatedCode.append(new Rust(tree.getChildren().get(1)).generateCode());
            return;
        }
        if (tree.getSubType().equals(RuleType.SUB)) {
            generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
            generatedCode.append(" - ");
            generatedCode.append(new Rust(tree.getChildren().get(1)).generateCode());
            return;
        }
        if (tree.getSubType().equals(RuleType.DEFAULT)) {
            generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
            return;
        }
    }


    private static void gtStatement(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        if (tree.getChildren().size() >= 2) {
            generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
            generatedCode.append(" > ");
            generatedCode.append(new Rust(tree.getChildren().get(1)).generateCode());
        }
    }

    private static void ltStatement(AbstractSyntaxTree tree, StringBuilder generastedCode) {
        if (tree.getChildren().size() >= 2) {
            generastedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
            generastedCode.append(" < ");
            generastedCode.append(new Rust(tree.getChildren().get(1)).generateCode());
        }
    }

    private static void equalityStatement(AbstractSyntaxTree tree, StringBuilder genertedCode) {
        if (tree.getChildren().size() >= 2) {
            genertedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
            genertedCode.append(" == ");
            genertedCode.append(new Rust(tree.getChildren().get(1)).generateCode());
        }
    }

    private static void comparisonStatement(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
    }

    private static void inversionStatement(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        if (tree.getSubType().equals(RuleType.MULTI)) {
            generatedCode.append("!");
            generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
            return;
        } else
            generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
    }

    private static void conjunctionStatement(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        if (tree.getSubType().equals(RuleType.MULTI)) {
            generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
            generatedCode.append(" && ");
            generatedCode.append(new Rust(tree.getChildren().get(1)).generateCode());
            return;
        } else {
            generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
            return;
        }
    }

    private static void disjunctionStatment(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        if (tree.getSubType().equals(RuleType.MULTI)) {
            generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
            generatedCode.append(" || ");
            generatedCode.append(new Rust(tree.getChildren().get(1)).generateCode());
            return;
        } else {
            generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
            return;
        }
    }

    private static void whileStatement(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        generatedCode.append("while (");
        generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
        generatedCode.append(") ");
        generatedCode.append(new Rust(tree.getChildren().get(1)).generateCode());
    }

    private static void generateCases(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        if (tree.getSubType().equals(RuleType.MULTI)) {
            generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
            generatedCode.append(" => ");
            generatedCode.append(new Rust(tree.getChildren().get(1)).generateCode());
            generatedCode.append(",\n");
            generatedCode.append(new Rust(tree.getChildren().get(2)).generateCode());
        } else {
            generatedCode.append(" _ => ");
            generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
        }
    }

    private static void swichStatement(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        generatedCode.append("match " + new Rust(tree.getChildren().get(0)).generateCode() + " {\n");
        generatedCode.append(new Rust(tree.getChildren().get(1)).generateCode());
        generatedCode.append("}\n");
    }

    private static void followStatemnet(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        switch (tree.getSubType()) {
            case MULTI:
                generatedCode.append("{\n");
                generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
                generatedCode.append("}\n");
                break;
            case SINGLE:
                generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
                break;
            case EMPTY:
                generatedCode.append("{ }\n");
                break;
        }
    }

    private static void assignmentStmnt(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode() + " = ");
        generatedCode.append(new Rust(tree.getChildren().get(1)).generateCode());
    }

    private static void statementsStatement(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        if (tree.getSubType().equals(RuleType.MULTI) && tree.getChildren().size() >= 2) {
            generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
            generatedCode.append(new Rust(tree.getChildren().get(1)).generateCode());
            return;
        } else {
            generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
            return;
        }
    }

    private static void ifStatement(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        generatedCode.append("if (");
        generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
        generatedCode.append(") ");
        generatedCode.append(new Rust(tree.getChildren().get(1)).generateCode());
        generatedCode.append("else ");
        generatedCode.append(new Rust(tree.getChildren().get(2)).generateCode());
    }

    private static void programStatement(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        generatedCode.append("fn ");
        generatedCode.append(new Rust(tree.getChildren().get(0)).generateCode());
        generatedCode.append("() {\n");
        generatedCode.append(new Rust(tree.getChildren().get(1)).generateCode());
        generatedCode.append("}\n");

    }
}
