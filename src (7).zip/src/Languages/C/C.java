package Languages.C;

import Languages.Code;
import Languages.Java.Java;
import Transpiler.AbstractSyntaxTree;
import Transpiler.NodeType;
import Transpiler.RuleType;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.regex.Pattern;

public class C extends Code {

    public C(String code) {
        super(code);
    }

    public C(AbstractSyntaxTree ast) {
        super(ast);
    }

    @Override
    public AbstractSyntaxTree parseToAST() {
        CLexer lexer = new CLexer(new StringReader(this.code));
        CParser parser = new CParser(lexer);
        try {
            Object result = parser.parse().value;
            this.ast = (AbstractSyntaxTree) result;
            return this.ast;
        } catch (Exception e) {
            System.err.println("Parser error: " + e.getMessage());
            this.ast = null;
            return null;
        }
    }

    @Override
    public String generateCode() {
        AbstractSyntaxTree tree = this.ast;
        StringBuilder generatedCode = new StringBuilder();
        if (tree == null)
            return generatedCode.toString();
        switch (tree.getType()) {
            case IF:
                ifStatement(tree, generatedCode);
                break;
            case PROGRAM:
                programStatement(tree, generatedCode);
                break;
            case STATEMENTS, OPTIONS:
                statementsStatement(tree, generatedCode);
                break;
            case STATEMENT:
                statementstatement(tree, generatedCode);
                break;
            case DECLARATION:
                generatedCode.append("int ");
                generatedCode.append(new C(tree.getChildren().get(0)).generateCode());
                break;
            case ASSIGNMENT:
                assignmentStmnt(tree, generatedCode);
                break;
            case ASSIGNMENTS:
                assignments(tree, generatedCode);
                break;
            case FOLLOW_STATEMENTS:
                followStatemnet(tree, generatedCode);
                break;
            case SWITCH:
                swichStatement(tree, generatedCode);
                break;
            case CASES:
                generateCases(tree, generatedCode);
                break;
            case WHILE:
                whileStatement(tree, generatedCode);
                break;
            case DISJUNCTION:
                disjunctionStatment(tree, generatedCode);
                break;
            case CONJUNCTION:
                conjunctionStatement(tree, generatedCode);
                break;
            case INVERSION:
                inversionStatement(tree, generatedCode);
                break;
            case COMPARISON:
                comparisonStatement(tree, generatedCode);
                break;
            case EQ:
                equalityStatement(tree, generatedCode);
                break;
            case LT:
                ltStatement(tree, generatedCode);
                break;
            case GT:
                gtStatement(tree, generatedCode);
                break;
            case SUM:
                sumStatement(tree, generatedCode);
                break;
            case TERM:
                termStatement(tree, generatedCode);
                break;
            case MODULO:
                modulaStatement(tree, generatedCode);
                break;
            case FACTOR:
                factorStatement(tree, generatedCode);
                break;
            case PRIMARY:
                primaryStatement(tree, generatedCode);
                break;
            case ID:
                generatedCode.append(tree.getLexeme());
                break;
            case NUM:
                generatedCode.append(tree.getLexeme());
                break;
            case PRINT:
                print(tree, generatedCode);
                break;
        }
        return generatedCode.toString();
    }

    private void assignments(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        if (tree.getSubType().equals(RuleType.MULTI)) {
            generatedCode.append(new C(tree.getChildren().get(0)).generateCode());
            generatedCode.append(", ");
            generatedCode.append(new C(tree.getChildren().get(1)).generateCode());
        } else {
            generatedCode.append(new C(tree.getChildren().get(0)).generateCode());
        }
    }

    private static void print(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        if (tree.getSubType().equals(RuleType.MULTI)) {
            generatedCode.append(" << ");
            generatedCode.append(new C(tree.getChildren().get(0)).generateCode());
            generatedCode.append(" << ");
            generatedCode.append(new C(tree.getChildren().get(1)).generateCode());
        } else {
            generatedCode.append(" << ");
            generatedCode.append(new C(tree.getChildren().get(0)).generateCode());
        }
    }

    private void primaryStatement(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        generatedCode.append(new C(tree.getChildren().get(0)).generateCode());
    }

    private void factorStatement(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        switch (tree.getSubType()) {
            case POSITIVE -> {
                generatedCode.append("+");
                generatedCode.append(new C(tree.getChildren().get(0)).generateCode());
            }
            case NEGATIVE -> {
                generatedCode.append("-");
                generatedCode.append(new C(tree.getChildren().get(0)).generateCode());
            }
            case PAR -> {
                generatedCode.append("(");
                generatedCode.append(new C(tree.getChildren().get(0)).generateCode());
                generatedCode.append(")");
            }
            case DEFAULT -> {
                generatedCode.append(new C(tree.getChildren().get(0)).generateCode());
            }
        }
    }

    private void modulaStatement(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        switch (tree.getSubType()) {
            case MULTI -> {
                generatedCode.append(new C(tree.getChildren().get(0)).generateCode());
                generatedCode.append(" % ");
                generatedCode.append(new C(tree.getChildren().get(1)).generateCode());
            }
            default -> generatedCode.append(new C(tree.getChildren().get(0)).generateCode());

        }
    }

    private void termStatement(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        switch (tree.getSubType()) {
            case TIMES -> {
                generatedCode.append(new C(tree.getChildren().get(0)).generateCode());
                generatedCode.append(" * ");
                generatedCode.append(new C(tree.getChildren().get(1)).generateCode());
            }
            case DIVIDES -> {
                generatedCode.append(new C(tree.getChildren().get(0)).generateCode());
                generatedCode.append(" / ");
                generatedCode.append(new C(tree.getChildren().get(1)).generateCode());
            }
            case DEFAULT -> {
                generatedCode.append(new C(tree.getChildren().get(0)).generateCode());
                break;
            }
        }
    }

    private void sumStatement(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        switch (tree.getSubType()) {
            case SUB -> {
                generatedCode.append(new C(tree.getChildren().get(0)).generateCode());
                generatedCode.append(" - ");
                generatedCode.append(new C(tree.getChildren().get(1)).generateCode());
            }
            case ADD -> {
                generatedCode.append(new C(tree.getChildren().get(0)).generateCode());
                generatedCode.append(" + ");
                generatedCode.append(new C(tree.getChildren().get(1)).generateCode());
            }
            case DEFAULT -> {
                generatedCode.append(new C(tree.getChildren().get(0)).generateCode());
                break;
            }
        }
    }

    private void gtStatement(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        generatedCode.append(new C(tree.getChildren().get(0)).generateCode());
        generatedCode.append(" > ");
        generatedCode.append(new C(tree.getChildren().get(1)).generateCode());
    }

    private void ltStatement(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        generatedCode.append(new C(tree.getChildren().get(0)).generateCode());
        generatedCode.append(" < ");
        generatedCode.append(new C(tree.getChildren().get(1)).generateCode());
    }

    private void equalityStatement(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        generatedCode.append(new C(tree.getChildren().get(0)).generateCode());
        generatedCode.append(" == ");
        generatedCode.append(new C(tree.getChildren().get(1)).generateCode());
    }

    private void comparisonStatement(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        generatedCode.append(new C(tree.getChildren().get(0)).generateCode());
    }

    private void inversionStatement(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        switch (tree.getSubType()) {
            case MULTI -> {
                generatedCode.append("!");
                generatedCode.append(new C(tree.getChildren().get(0)).generateCode());
            }
            default -> {
                generatedCode.append(new C(tree.getChildren().get(0)).generateCode());
            }
        }
    }

    private void conjunctionStatement(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        switch (tree.getSubType()) {
            case MULTI -> {
                generatedCode.append(new C(tree.getChildren().get(0)).generateCode());
                generatedCode.append(" && ");
                generatedCode.append(new C(tree.getChildren().get(1)).generateCode());
            }
            default -> {
                generatedCode.append(new C(tree.getChildren().get(0)).generateCode());
            }
        }
    }

    private void disjunctionStatment(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        switch (tree.getSubType()) {
            case MULTI -> {
                generatedCode.append(new C(tree.getChildren().get(0)).generateCode());
                generatedCode.append(" || ");
                generatedCode.append(new C(tree.getChildren().get(1)).generateCode());
            }
            default -> {
                generatedCode.append(new C(tree.getChildren().get(0)).generateCode());
            }
        }
    }

    private void whileStatement(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        generatedCode.append("while (");
        generatedCode.append(new C(tree.getChildren().get(0)).generateCode());
        generatedCode.append(") ");
        generatedCode.append(new C(tree.getChildren().get(1)).generateCode());
    }

    private static void generateCases(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        if (tree.getSubType().equals(RuleType.DEFAULT)) {
            generatedCode.append("default: ");
            generatedCode.append(new C(tree.getChildren().get(0)).generateCode());
        } else {
            ArrayList<Integer> cases = new ArrayList<>();
            char[] Cases = new C(tree.getChildren().get(0)).generateCode().toCharArray();
            for (char c : Cases) {
                if (Pattern.matches("[0-9]", String.valueOf(c))) {
                    cases.add(Integer.parseInt(String.valueOf(c)));
                }
            }
            for (int i : cases) {
                generatedCode.append("case ");
                generatedCode.append(i);
                generatedCode.append(": ");
                AbstractSyntaxTree ast = tree.getChildren().get(1);
                ast.setSubType(RuleType.SINGLE);
                generatedCode.append(new C(ast).generateCode());
            }
            generatedCode.append(new C(tree.getChildren().get(2)).generateCode());
        }
    }

    private void swichStatement(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        generatedCode.append("switch (");
        generatedCode.append(new C(tree.getChildren().get(0)).generateCode());
        generatedCode.append(") {\n");
        generatedCode.append(new C(tree.getChildren().get(1)).generateCode());
        generatedCode.append("}\n");
    }

    private void followStatemnet(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        switch (tree.getSubType()) {
            case MULTI -> {
                generatedCode.append(" {\n");
                generatedCode.append(new C(tree.getChildren().get(0)).generateCode());
                generatedCode.append(" }\n");
            }
            case SINGLE -> {
                generatedCode.append(new C(tree.getChildren().get(0)).generateCode());
            }
            case EMPTY -> {
                generatedCode.append("{}\n");
            }
        }
    }

    private void assignmentStmnt(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        generatedCode.append(new C(tree.getChildren().get(0)).generateCode());
        generatedCode.append(" = ");
        generatedCode.append(new C(tree.getChildren().get(1)).generateCode());
    }

    private void statementsStatement(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        switch (tree.getSubType()) {
            case MULTI -> {
                generatedCode.append(new C(tree.getChildren().get(0)).generateCode());
                generatedCode.append(new C(tree.getChildren().get(1)).generateCode());
            }
            default -> {
                generatedCode.append(new C(tree.getChildren().get(0)).generateCode());
                break;
            }
        }
    }

    private void statementstatement(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        switch (tree.getSubType()) {
            case DECLARE, ASSIGNMENTS -> {
                generatedCode.append(new C(tree.getChildren().get(0)).generateCode());
                generatedCode.append(";\n");
            }
            case BREAK -> {
                generatedCode.append("break;\n");
            }
            case CONTINUE -> {
                generatedCode.append("continue;\n");
            }
            case PRINT -> {
                generatedCode.append("cout <<");
                generatedCode.append(new C(tree.getChildren().get(0)).generateCode() + ";\n");
            }
            case IF, SWITCH, WHILE -> {
                generatedCode.append(new C(tree.getChildren().get(0)).generateCode());
            }
        }
    }

    private void programStatement(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        generatedCode.append("void ");
        generatedCode.append(new C(tree.getChildren().get(0)).generateCode());
        generatedCode.append(" () {\n");
        generatedCode.append(new C(tree.getChildren().get(1)).generateCode());
        generatedCode.append("}\n");

    }

    private void ifStatement(AbstractSyntaxTree tree, StringBuilder generatedCode) {
        generatedCode.append("if (");
        generatedCode.append(new C(tree.getChildren().get(0)).generateCode());
        generatedCode.append(")");
        generatedCode.append(new C(tree.getChildren().get(1)).generateCode());
        generatedCode.append("else ");
        generatedCode.append(new C(tree.getChildren().get(2)).generateCode());
    }


}
