package Transpiler;

import Languages.Runnable;

import java.util.ArrayList;
import java.util.List;

public class Transpiler<T extends Runnable> {

    List<T> runnables = new ArrayList<>();

    public void addCode(T code) {
        runnables.add(code);
    }

    public List<AbstractSyntaxTree> getAbstractSyntaxTrees() {
        List<AbstractSyntaxTree> abstractSyntaxTrees = new ArrayList<>();
        for (int i = 0; i < runnables.size(); i++) {
            abstractSyntaxTrees.add(runnables.get(i).parseToAST());
        }
        return abstractSyntaxTrees;
    }

    public List<String> getCodes() {
        List<String> codes = new ArrayList<>();
        for (int i = 0; i < runnables.size(); i++) {
            codes.add(runnables.get(i).generateCode());
        }
        return codes;
    }

    public List<T> getSimilarRunnables(T runnable) {
        List<T> similrRunnables = new ArrayList<>();
        for (int i = 0; i < runnables.size(); i++) {
            if (runnables.get(i).parseToAST().equals(runnable.parseToAST()))
                similrRunnables.add(runnables.get(i));
        }
        return similrRunnables;
    }

    public List<T> getUniqueRunnables() {
        List<T> notSimilrRunnables = new ArrayList<>();
        for (int i = 0; i < runnables.size(); i++) {
            if (getSimilarRunnables(runnables.get(i)).size() == 1)
                notSimilrRunnables.add(runnables.get(i));
        }
        return notSimilrRunnables;
    }
}
