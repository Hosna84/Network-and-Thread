import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StoreServer extends Thread {
    private static Map<String, Integer> inventory = new HashMap<>();
    private static Map<String, Integer> prices = new HashMap<>();
    private Socket socket;
    private Customer currentCustomer;

    public StoreServer(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        try {
            DataInputStream dataInputStream = new DataInputStream(socket.getInputStream());
            DataOutputStream dataOutputStream = new DataOutputStream(socket.getOutputStream());

            while (true) {
                String inputFromCustumer = dataInputStream.readUTF();
                String[] partsOfMessage = inputFromCustumer.split(":");
                if (partsOfMessage[0].equals("register") && partsOfMessage.length == 4 &&
                        isInteger(partsOfMessage[1]) && isInteger(partsOfMessage[3]))
                    registerCustomer(partsOfMessage, dataOutputStream);
                else if (partsOfMessage[0].equals("login") && partsOfMessage.length == 2 &&
                        isInteger(partsOfMessage[1]))
                    loginCustomer(partsOfMessage, dataOutputStream);
                else if (partsOfMessage[0].equals("logout"))
                    logout(partsOfMessage, dataOutputStream);
                else if (partsOfMessage[0].equals("get price") && partsOfMessage.length == 2)
                    getPrice(partsOfMessage, dataOutputStream);
                else if (partsOfMessage[0].equals("get quantity") && partsOfMessage.length == 2)
                    getQuantity(partsOfMessage, dataOutputStream);
                else if (partsOfMessage[0].equals("get money"))
                    getCustomerMoney(dataOutputStream);
                else if (partsOfMessage[0].equals("charge") && partsOfMessage.length == 2
                        && isInteger(partsOfMessage[1]))
                    chargeCustomer(Integer.parseInt(partsOfMessage[1]), dataOutputStream);
                else if (partsOfMessage[0].equals("purchase") && partsOfMessage.length == 3
                        && isInteger(partsOfMessage[2]))
                    purchaseProduct(partsOfMessage[1], Integer.parseInt(partsOfMessage[2]), dataOutputStream);
                else dataOutputStream.writeUTF("Invalid command!");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void registerCustomer(String[] partsOfMessage, DataOutputStream dataOutputStream)
            throws IOException {
        String id = partsOfMessage[1];
        String name = partsOfMessage[2];
        String money = partsOfMessage[3];
        if (Customer.allCustomers.containsKey(id)) {
            dataOutputStream.writeUTF("We had this id before!");
            return;
        }
        Customer customer = new Customer(name, id, Integer.parseInt(money));
        dataOutputStream.writeUTF("Registered successfully!");
    }

    private void loginCustomer(String[] partsOfMessage, DataOutputStream dataOutputStream)
            throws IOException {
        String id = partsOfMessage[1];
        if (!isValidId(id)) {
            dataOutputStream.writeUTF("Invalid id!");
            return;
        }
        currentCustomer = Customer.getAllCustomers().get(id);
        dataOutputStream.writeUTF("Logged in successfully!");
    }

    private void logout(String[] partsOfMessage, DataOutputStream dataOutputStream)
            throws IOException {
        if (currentCustomer == null) {
            dataOutputStream.writeUTF("No logged in customer!");
            return;
        }
        currentCustomer = null;
        dataOutputStream.writeUTF("Logged out successfully!");
    }

    private boolean isValidId(String id) {
        if (Customer.allCustomers.containsKey(id)) return true;
        return false;
    }

    private boolean isValidProductName(String productName) {
        if (inventory.containsKey(productName)) return true;
        return false;
    }

    private void chargeCustomer(int chargeAmount, DataOutputStream dataOutputStream) throws IOException {
        if (currentCustomer == null) {
            dataOutputStream.writeUTF("No logged in customer!");
            return;
        }
        currentCustomer.setMoney(currentCustomer.getMoney() + chargeAmount);
        dataOutputStream.writeUTF("Charged!");
    }

    private void getPrice(String[] partsOfMessage, DataOutputStream dataOutputStream)
            throws IOException {
        if (!isValidProductName(partsOfMessage[1])) {
            dataOutputStream.writeUTF("Invalid product name!");
            return;
        }
        if (prices.containsKey(partsOfMessage[1]))
            dataOutputStream.writeUTF("Price for " + partsOfMessage[1] + " is "
                    + prices.get(partsOfMessage[1]).toString());
    }

    private void getQuantity(String[] partsOfMessage, DataOutputStream dataOutputStream)
            throws IOException {
        if (!isValidProductName(partsOfMessage[1])) {
            dataOutputStream.writeUTF("Invalid product name!");
            return;
        }
        if (inventory.containsKey(partsOfMessage[1]))
            dataOutputStream.writeUTF("Inventory of this shoes is " + inventory.get(partsOfMessage[1]));

    }

    private void purchaseProduct(String productName, int quantity, DataOutputStream dataOutputStream)
            throws IOException {
        synchronized (this) {
            if (currentCustomer == null) {
                dataOutputStream.writeUTF("No logged in user!");
                return;
            }
            if (!inventory.containsKey(productName)) {
                dataOutputStream.writeUTF("Invalid product name!");
                return;
            }
            if (inventory.get(productName) < quantity) {
                dataOutputStream.writeUTF("Not enough inventory!");
                return;
            }
            if (currentCustomer != null && prices.get(productName) * quantity > currentCustomer.getMoney()) {
                dataOutputStream.writeUTF("Not enough money!");
                return;
            }
            inventory.replace(productName, inventory.get(productName) - quantity);
            if (currentCustomer != null)
                currentCustomer.setMoney(currentCustomer.getMoney() - prices.get(productName) * quantity);
            dataOutputStream.writeUTF("Purchase successful");
        }
    }

    private void getCustomerMoney(DataOutputStream dataOutputStream) throws IOException {
        if (currentCustomer == null) {
            dataOutputStream.writeUTF("No logged in customer!");
            return;
        }
        dataOutputStream.writeUTF("Money that this customer has " + currentCustomer.getMoney());
    }

    private boolean isInteger(String s) {
        if (s == null || s.isEmpty()) {
            return false;
        }
        for (char c : s.toCharArray()) {
            if (!Character.isDigit(c)) {
                return false;
            }
        }
        return true;
    }


    public static void main(String[] args) {
        inventory.put("shoe1", 5);
        inventory.put("shoe2", 5);
        inventory.put("shoe3", 5);
        prices.put("shoe1", 80);
        prices.put("shoe2", 90);
        prices.put("shoe3", 100);

        try (ServerSocket serverSocket = new ServerSocket(5001)) {
            while (true) {
                Socket socket = serverSocket.accept();
                new StoreServer(socket).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

class Customer {
    private String name;
    private String id;
    private int money;
    public static HashMap<String, Customer> allCustomers = new HashMap<>();

    public Customer(String name, String id, int money) {
        this.name = name;
        this.id = id;
        this.money = money;
        allCustomers.put(id, this);
    }

    public static HashMap<String, Customer> getAllCustomers() {
        return allCustomers;
    }

    public String getName() {
        return this.name;
    }

    public String getId() {
        return this.id;
    }

    public int getMoney() {
        return money;
    }

    public void setMoney(int money) {
        this.money = money;
    }
}
