import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    public void start() {
        try {
            Socket socket = new Socket("127.0.0.1", 5001);
            DataInputStream dataInputStream = new DataInputStream(socket.getInputStream());
            DataOutputStream dataOutputStream = new DataOutputStream(socket.getOutputStream());
            Scanner scanner = new Scanner(System.in);
            while (true) {
                String command = scanner.nextLine();
                dataOutputStream.writeUTF(command);
                dataOutputStream.flush();
                String response = dataInputStream.readUTF();
                System.out.println(response);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        Client client = new Client();
        client.start();
    }
}

